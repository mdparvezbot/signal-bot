import telebot
import random
import time

TOKEN = "YOUR_BOT_TOKEN"
GROUP_ID = -1001234567890  # এখানে তোমার গ্রুপের আইডি বসাও

bot = telebot.TeleBot(TOKEN)

options = ["BIG", "SMALL"]

def send_signal():
    signal = random.choice(options)
    bot.send_message(GROUP_ID, f"Next Signal: {signal}")

# প্রতি ৫ মিনিটে একবার সিগন্যাল পাঠাবে
while True:
    try:
        send_signal()
        time.sleep(300)  # 300 সেকেন্ড = 5 মিনিট
    except Exception as e:
        print("Error:", e)
        time.sleep(10)
